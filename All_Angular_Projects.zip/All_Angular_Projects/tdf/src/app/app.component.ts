import { Component } from '@angular/core';
import { Employee } from './employee';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  // title = 'tdf';
  public id;
  public name;
  public salary;
  public department;
  public employees = [];
  public check = false;
  //employeeModel = new Employee(23, "Vishal", 5678, "cs");

  addEmployee() {
    // alert(this.employeeModel.id + " " + this.employeeModel.name +" " + this.employeeModel.salary + " " + this.employeeModel.department);
    this.employees.push({id: this.id, name: this.name, salary: this.salary, department: this.department});
  }
  deleteEmployee(employee) {
    let index = this.employees.indexOf(employee);
    this.employees.splice(index, 1);
  }
  edit() {
    this.check=true;
  }

  save() {
    this.check=false;
  }
}
