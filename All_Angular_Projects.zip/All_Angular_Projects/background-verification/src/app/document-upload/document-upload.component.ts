import { Component, OnInit } from '@angular/core';
import { DocumentUploadService } from '../document-upload.service';

@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['./document-upload.component.scss']
})
export class DocumentUploadComponent implements OnInit {

  documentToUpload: File = null; 

  constructor(private _documentUploadService: DocumentUploadService) { }

  ngOnInit() {
  }

  handleFileInput(documnets: FileList) {
    this.documentToUpload = documnets.item(0);
}

uploadFileToActivity() {
  this._documentUploadService.uploadDocument(this.documentToUpload).subscribe(data => {
    // do something, if upload success
    console.log(data)
    }, error => {
      console.log(error);
    });
}

// storeDocument() {
//   this._documentUploadService.uploadDocument(this.documentToUpload);
// }
}
