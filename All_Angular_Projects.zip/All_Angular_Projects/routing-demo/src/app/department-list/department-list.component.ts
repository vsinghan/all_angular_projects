import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-list',
  template: `
    <p>
      department-list works!
    </p>
  `,
  styles: []
})
export class DepartmentListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
