import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {

  public productId;
  public productName;
  public productCost;
  public productOnline;
  public productCategory;
  public categoryHasError = true;
  public stores = {
    store1:"",
    store2:"",
    store3:"",
    store4:""
  };

  public categories = ['Grocery', 'Mobile', 'Electronics', 'Cloths'];
  public selectedStores = [];

  constructor() { }

  ngOnInit() {
  }

  addProduct() {
    if(this.stores.store1) {
      this.selectedStores.push('');
    }
    if(this.stores.store2) {
      this.selectedStores.push(this.categories[1]);
    }
    if(this.stores.store3) {
      this.selectedStores.push(this.categories[2]);
    }
    if(this.stores.store4) {
      this.selectedStores.push(this.categories[3]);
    }
    console.log(this.productId + " " + this.productName + " " + this.productCost+ " " + this.productOnline + " " + this.productCategory + " " + this.selectedStores);
  }

  validateCategory(value) {
    if(value == 'default') {
      
    }
  }
}
